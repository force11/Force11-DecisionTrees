reject: See:

Making data open by design](https://docs.google.com/document/d/1I3vwpu_ppvBkL1gDSthLG0NYCZA_EUlVbFKdsR4xCg4/edit) to see some of the issues that should be considered up front.
