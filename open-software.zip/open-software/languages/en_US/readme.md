# Force11-Making Software Open

__Version 0.5__

This decision tree provides guidance on making software open, focusing on software that exists already.  For definitions of open, we used the [Open Source Definition[(https://opensource.org/osd-annotated)] from the Open Source Initiative.
