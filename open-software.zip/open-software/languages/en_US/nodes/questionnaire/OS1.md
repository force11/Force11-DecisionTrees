Does the software you wish to share already exist?

The "Yes" branch covers a set of conditions required for open software.  We have not yet completed the "No" branch, but you can infer the appropriate actions by going through the Yes branch and noting the requirements for making software open.  
