Do you have the rights to make the software open?

Has permission been obtained from your institution, colleagues, subjects for you to publish this software under an open license?  See [permissions worksheet](https://docs.google.com/document/d/1jLlWbzyTP9m3uMXPrAsrgEx5iXdPJvZ60cB7sDPGgxE/edit#heading=h.h5a8507jqfte) for guidance.
