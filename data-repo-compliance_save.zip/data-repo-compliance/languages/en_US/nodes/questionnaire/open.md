Are the data provided in an open format?

 Data should be stored in a non-proprietary format, i.e., a format that is published and free for re-use by anyone, e.g., CSV.  In contrast, a proprietary format is not published and can only be read by certain commercial software.  As the goal of publishing data in a repository is for openness and re-use, data that is reliant on propriety software is by definition non-commons compliant.  Adapted from [Wikipedia](https://en.wikipedia.org/wiki/Proprietary_format)
