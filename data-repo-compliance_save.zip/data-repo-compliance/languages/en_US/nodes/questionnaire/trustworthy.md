Does the repository adhere to the requirements for the Data Repository Gold Seal of Approval? 

### Terms
* *Data Repository Gold Seal of Approval*: see https://www.datasealofapproval.org/en/information/requirements/
