DataTags: consists of Assertions.

Assertions: some of Open,
                    FAIR,
                    Citable,
                    Trustworthy.
