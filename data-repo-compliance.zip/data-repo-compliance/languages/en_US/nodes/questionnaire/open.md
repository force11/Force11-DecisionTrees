Does the repository provide access to the data with minimal or no restrictions?

 Access to the data should be unfettered, without even requiring an account, but requiring registraiton before using the data would be considered a minimal restriction.  Similarly, minimal restrictions may also include requiring special access for accessing large amounts of data, e.g., an API key.
