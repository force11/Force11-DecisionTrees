Are you free to download the data and reuse it with no or  minimal restrictions?

Many repositories that claim to be open are only open for humans to read, not for machine-based access or for re-use. So it is important to check before depositing data that the data is free to reuse according to the definition of the commons. 
