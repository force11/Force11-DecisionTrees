Are the data covered by a commons-compliant license?

Data should be covered by the least restrictive license possible consistent with ethical and legal constraints on some types of data, e.g., human subjects data.  For a list of open licenses for data, see the [Open Definition](http://opendefinition.org/licenses/#Data). 
