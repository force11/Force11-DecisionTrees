# DataTags
<-- TODO: describe DataTags

# DataTags/Assertions
<-- TODO: describe DataTags/Assertions

# DataTags/Assertions/Open
<-- TODO: describe DataTags/Assertions/Open

# DataTags/Assertions/FAIR
<-- TODO: describe DataTags/Assertions/FAIR

# DataTags/Assertions/Citable
<-- TODO: describe DataTags/Assertions/Citable

# DataTags/Assertions/Trustworthy
<-- TODO: describe DataTags/Assertions/Trustworthy

