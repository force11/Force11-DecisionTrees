Does the *repository* provide the required metadata for supporting data citation?
